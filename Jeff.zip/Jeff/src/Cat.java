public class Cat {
    private String name;
    public Cat (String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String set)
    {
        name = set;
    }
    public String toString()
    {
        return "Cat: " +name;
    }
}
